package com.atahani.retrofit_sample.models;

/**
 * Error Model when error happened in http like 404
 */
public class ErrorModel {

    public String type;
    public String description;
    
}
