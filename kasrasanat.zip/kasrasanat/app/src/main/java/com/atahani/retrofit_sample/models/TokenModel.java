package com.atahani.retrofit_sample.models;

import java.util.Date;

/**
 * Token Model used in sign in, sign up and refresh token response
 */
public class TokenModel {
    public String access_token;
  //  public Long expire_in_sec;
    //public Date expire_at;
   // public String refresh_token;
    public String app_id;
}
