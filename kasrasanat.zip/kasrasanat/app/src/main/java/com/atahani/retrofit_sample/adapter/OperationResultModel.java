package com.atahani.retrofit_sample.adapter;

/**
 * operation result model like delete something
 */
public class OperationResultModel {
    public String type;
    public String description;
}
